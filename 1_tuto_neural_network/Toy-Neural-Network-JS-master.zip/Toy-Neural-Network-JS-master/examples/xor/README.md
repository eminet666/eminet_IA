## Variations:

* [NN XOR](https://codemehtm.github.io/nn) by cdeMtHtm - "I literally copied this from the video, but then, I added a little bit more."
